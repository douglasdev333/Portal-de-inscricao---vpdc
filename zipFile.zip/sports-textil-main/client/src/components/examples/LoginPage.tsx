import LoginPage from '../../pages/LoginPage';

export default function LoginPageExample() {
  return <LoginPage />;
}
