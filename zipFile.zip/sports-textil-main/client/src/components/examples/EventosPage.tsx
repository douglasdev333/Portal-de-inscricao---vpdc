import EventosPage from '../../pages/EventosPage';

export default function EventosPageExample() {
  return <EventosPage />;
}
