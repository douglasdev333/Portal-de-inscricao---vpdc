import CadastroPage from '../../pages/CadastroPage';

export default function CadastroPageExample() {
  return <CadastroPage />;
}
