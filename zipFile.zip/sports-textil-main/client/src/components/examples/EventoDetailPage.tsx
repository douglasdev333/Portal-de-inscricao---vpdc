import EventoDetailPage from '../../pages/EventoDetailPage';

export default function EventoDetailPageExample() {
  return <EventoDetailPage />;
}
