import MinhasInscricoesPage from '../../pages/MinhasInscricoesPage';

export default function MinhasInscricoesPageExample() {
  return <MinhasInscricoesPage />;
}
